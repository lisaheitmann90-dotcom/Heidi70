
export interface Activity {
  time?: string;
  description: string;
  icon: 'tuktuk' | 'temple' | 'boat' | 'market' | 'bar' | 'massage' | 'beach' | 'elephant' | 'island' | 'celebration' | 'plane' | 'food' | 'buddha' | 'lotus' | 'snorkeling' | 'noodles' | 'palm' | 'cocktail' | 'sun' | 'coconut' | 'seashell' | 'fish' | 'waves' | 'mapPin';
  mapUrl?: string;
}

export interface Dining {
  location: string;
  details?: string;
  mapUrl?: string;
}

export interface Day {
  date: string;
  displayDate: string;
  location: string;
  activities: Activity[];
  dinner?: Dining;
  accommodation: string;
  accommodationMapUrl?: string;
  isBirthday?: boolean;
}

export type View = 'welcome' | 'itinerary';
